import nltk
from nltk.collocations import *
from nltk.metrics.spearman import *

trigram_measures = nltk.collocations.TrigramAssocMeasures()


def ass_measure(for_test, gold_st, measure_name, file_name):
    final_set = []
    s = open(file_name, 'a', encoding='utf-8')
    tr_finder = TrigramCollocationFinder.from_documents([line.strip().split(' ,') for line in for_test])
    tr_finder.apply_freq_filter(7)
    scored_trgrams = tr_finder.score_ngrams(measure_name)
    for e in sorted(scored_trgrams, key = lambda x: x[1], reverse=True):
        for el in gold_st:
            if el[0] == e[0]:
                final_set.append(e[0])
                s.write(e[0][0] + ';' + e[0][1] + ';' + e[0][2] + ';' + str(e[1]) + '\n')
    final = '%0.1f' % spearman_correlation(gold_st, list(ranks_from_sequence(final_set)))
    s.close()
    return final


def main():
    words_tagged = open('tri_set.csv', 'r', encoding='utf-8').readlines()
    gold = open('gold_standard.csv', 'r', encoding='utf-8').readlines()
    gold_standard = list(ranks_from_sequence([tuple(l.strip().split(' ,')) for l in gold]))
    lkl = ass_measure(words_tagged, gold_standard, trigram_measures.likelihood_ratio, 'loglikelihood.csv')
    chi = ass_measure(words_tagged, gold_standard, trigram_measures.chi_sq, 'chi_sq.csv')
    print(lkl)
    print(chi)


if __name__ == '__main__':
    main()

# Вывод. Я чуть-чуть поменяла исходные данные (почистила в редакторе пробелы, см tri_set.csv)
# Золотой стандарт составляла по частотному списку триграмм из задания (используя метрику raw.frequency с ограничение по частоте триграммы 7).
# Взяты первые десять триграмм списка, отсортированного от наиб к наим показателю частоты.
# То есть я сравнивала как соотносятся метод выделения коллокаций "в лоб" (относительные частоты сочетаний в корпусе) с более изощренными метриками:likelihood_ratio и chi_sq.
# Меры - likelihood_ratio и chi_sq в исследуемом корпусе. Результаты:0.8 для likelihood_ratio и -0.1 для chi_sq.
# Методом проб и ошибок я выяснила, что если поставить частотны фильтр, то показатели коэф-та Спирмана улучшаются, поэтому применила фильтр.
# Для подсчета я использовала ранжирование от 0 до 9 для золотого стандарта и для исследуемой метрики.
#Распределение триграмм по относительной частоте намного больше похоже на ранжирование в тесте likelihood_ratio, нежели чем на хи-квадрат.
# Я создала csv-файлы для двух метрик, где есть составляющие триграммы и значение соответствующей метрики.


 


