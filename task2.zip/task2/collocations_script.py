import nltk
from nltk.collocations import *
from nltk.metrics.spearman import *

trigram_measures = nltk.collocations.TrigramAssocMeasures()


def ass_measure(for_test, gold_st, measure_name, file_name):
    final_set = []
    s = open(file_name, 'a', encoding='utf-8')
    tr_finder = TrigramCollocationFinder.from_documents([line.strip().split(' ,') for line in for_test])
    tr_finder.apply_freq_filter(7)
    scored_trgrams = tr_finder.score_ngrams(measure_name)
    for index,e in enumerate(sorted(scored_trgrams, key = lambda x: x[1], reverse=True)):
        for el in gold_st:
            if el[0] == e[0]:
                final_set.append((e[0], index))
                s.write(e[0][0] + ';' + e[0][1] + ';' + e[0][2] + ';' + str(e[1]) + '\n')
    final = '%0.1f' % spearman_correlation(gold_st, final_set)
    s.close()
    return final


def main():
    words_tagged = open('tri_set.csv', 'r', encoding='utf-8').readlines()
    gold = open('gold_standard.csv', 'r', encoding='utf-8').readlines()
    gold_standard = list(ranks_from_sequence([tuple(l.strip().split(' ,')) for l in gold]))
    lkl = ass_measure(words_tagged, gold_standard, trigram_measures.likelihood_ratio, 'loglikelihood.csv')
    freq = ass_measure(words_tagged, gold_standard, trigram_measures.raw_freq, 'frequency.csv')
    print(lkl)
    print(freq)


if __name__ == '__main__':
    main()

#Вывод. Я чуть-чуть поменяла исходные данные (почистила в редакторе пробелы, см tri_set.csv)
#Золотой стандарт составляла, используя триграммы в НКРЯ и попросив знакомых юристов проставить ранки по их интуиции.
#Меры - likelihood_ratio и частота триграмм в исследуемом корпусе (raw_freq). Результаты:0.3 для likelihood_ratio и -0.3 для raw_freq.
#Методом проб и ошибок я выяснила, что если поставить частотны фильтр, то показатели коэф-та Спирмана улучшаются, поэтому применила фильтр.
#Стоит отметить, что в ранжированных списках loglikelihood и raw.frequency триграммы из золотого стандарта находятся довольно "скученно":
#самая низкоранжированная триграмма - на 16 месте в списке.По ранжированию (схожесть позиций в списке) likelihood_ratio больше похож на золотой стандарт, чем raw_freq.
#Я создала csv-файлы для двух метрик, где есть составляющие триграммы и значение соответствующей метрики.


 


