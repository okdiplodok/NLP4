import csv
import pymorphy2

rows = []
punct = '”“".,«»\\/*!:;—()\'-%`.?―[]'
morph = pymorphy2.MorphAnalyzer()
header1 = ('prevword', 'nextword', 'prevtag', 'nexttag', 'class')
header2 = ('prevword', 'nextword', 'prevtag', 'nexttag', 'class', 'animals', 'comet', 'column', 'vehicle', 'study', 'dust', 'hair', 'rod', 'clothes')

def animals(line):
    ani = [('лев', 'NOUN'), ('кошка', 'NOUN'), ('кот', 'NOUN'), ('пёс', 'NOUN'), ('пес', 'NOUN'), ('собака', 'NOUN'),
           ('коза', 'NOUN'), ('змея', 'NOUN'), ('жар-птица', 'NOUN'), ('волк', 'NOUN'), ('воробей', 'NOUN'), ('лещ', 'NOUN'),
           ('щука', 'NOUN'), ('заяц', 'NOUN'), ('птица', 'NOUN'), ('мышка', 'NOUN'), ('сперматозоид', 'NOUN'), ('лошадь', 'NOUN'),
           ('кобыла', 'NOUN'), ('зев', 'NOUN'), ('лапа', 'NOUN'), ('павлин', 'NOUN'), ('лисица', 'NOUN')]
    for item in ani:
        if item in line:
            return '1'
    return '0'


def comet(line1):
    com = [('комета', 'NOUN'), ('ракета', 'NOUN')]
    for i in com:
        if i in line1:
            return '1'
    return '0'


def column(line2):
    col = [('колонна', 'NOUN'), ('очередь', 'NOUN'), ('шеренга', 'NOUN')]
    for i in col:
        if i in line2:
            return '1'
    return '0'

def vehicle(line3):
    veh = [('самолет', 'NOUN'), ('поезд', 'NOUN'), ('дирижабль', 'NOUN'), ('субмарина', 'NOUN'), ('товарный', 'ADJF'), ('самолёт', 'NOUN')]
    for i in veh:
        if i in line3:
            return '1'
    return '0'

def study(line4):
    st = [('сессия', 'NOUN'), ('зачет', 'NOUN'), ('экзамен', 'NOUN'), ('зачёт', 'NOUN')]
    for i in st:
        if i in line4:
            return '1'
    return '0'


def dust(line5):
    d = [('пыльный', 'NOUN'), ('пыль', 'NOUN'), ('дым', 'NOUN')]
    for i in d:
        if i in line5:
            return '1'
    return '0'

def hair(line6):
    h = [('затылок', 'NOUN'), ('волос', 'NOUN')]
    for i in h:
        if i in line6:
            return '1'
    return '0'


def rod(line7):
    r = [('прут', 'NOUN'), ('щетка', 'NOUN'), ('щётка', 'NOUN')]
    for i in r:
        if i in line7:
            return '1'
    return '0'


def clothes(line8):
    if ('рубашка', 'NOUN') in line8:
        return '1'
    return '0'

with open('raw_data.csv', newline='', encoding='utf-8') as csvfile:
    raw_data = csv.reader(csvfile, delimiter='\t')
    out_rows1 = []
    out_rows2 = []
    for row in raw_data:
        lemmas = []
        text = row[1].lower().split(' ')
        tail_class = row[2]
        for i in range(len(text)):
            text[i] = text[i].strip(punct).lstrip(punct)
            if text[i].isalpha():
                ana = morph.parse(text[i])[0]
                lemma_pos = (ana.normal_form, ana.tag.POS)
                lemmas.append(lemma_pos)
        if ('хвост', 'NOUN') not in lemmas:
            print(lemmas)
        index = lemmas.index(('хвост', 'NOUN'))
        if index == 0:
            prevword = '_'
            prevpos = '_'
            nextword = lemmas[1][0]
            nextpos = lemmas[1][1]
        elif index == len(lemmas) - 1:
            prevword = lemmas[index-1][0]
            prevpos = lemmas[index-1][1]
            nextword = '.'
            nextpos = '.'
        else:
            prevword = lemmas[index-1][0]
            prevpos = lemmas[index-1][1]
            nextword = lemmas[index+1][0]
            nextpos = lemmas[index+1][1]
        out_rows1.append((prevword, prevpos, nextword, nextpos, tail_class))
        #print(lemmas)
        #print(animals(lemmas), comet(lemmas), column(lemmas), vehicle(lemmas), study(lemmas), dust(lemmas), hair(lemmas), rod(lemmas), clothes(lemmas))
        out_rows2.append((prevword, prevpos, nextword, nextpos, tail_class, animals(lemmas), comet(lemmas), column(lemmas), vehicle(lemmas),
                          study(lemmas), dust(lemmas), hair(lemmas), rod(lemmas), clothes(lemmas)))


with open('features.csv', 'w', encoding='utf-8') as w:
    out = csv.writer(w, delimiter=',')
    out.writerow(header1)
    out.writerows(out_rows1)

with open('features_keywords.csv', 'w', encoding='utf-8') as j:
    out2 = csv.writer(j, delimiter=',')
    out2.writerow(header2)
    out2.writerows(out_rows2)

print('Done!')
        
                
